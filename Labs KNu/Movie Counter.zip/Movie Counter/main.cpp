#include <iostream>
#include "Library.h"

int main()
{
    Library mleko;
    return 0;
}

#ifndef __LIBRARY_H_
#define __LIBRARY_H_
#define MAX_NO_MOVIES 100
#include "Movie.h"

class Library{
public:
        Library();
        ~Library();
        //Movie&::
private:
    Movie* m_arrayOfMovies;


};

#endif // __LIBRARY_H_
